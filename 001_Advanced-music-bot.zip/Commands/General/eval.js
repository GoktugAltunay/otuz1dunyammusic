module.exports = {
	name: "eval",
	aliases: ["e"],
	code: `$eval[$message]
	$onlyIf[$authorID==920942629980635146;]`
};
