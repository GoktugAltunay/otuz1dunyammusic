module.exports = {
    prefix: require("./config.json").prefix,
    MUSIC_embedMessage: "",
    MUSIC_channel: ""
}